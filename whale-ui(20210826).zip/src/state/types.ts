import BigNumber from 'bignumber.js'
import { AutoFarmConfig, FarmConfig, PoolConfig } from 'config/constants/types'

export interface Farm extends FarmConfig {
  tokenAmount?: BigNumber
  // quoteTokenAmount?: BigNumber
  lpTotalInMC?: BigNumber
  lpTotalInQuoteToken?: BigNumber
  tokenPriceVsQuote?: BigNumber
  poolWeight?: number
  depositFeeBP?: number
  eggPerBlock?: number
    userData?: {
    allowance: BigNumber
    tokenBalance: BigNumber
    stakedBalance: BigNumber
    earnings: BigNumber
  }
}

export interface AutoFarm extends AutoFarmConfig {
  tokenAmount?: BigNumber
  // quoteTokenAmount?: BigNumber
  lpTotalInQuoteToken?: BigNumber
  lpTotalInMC?: BigNumber
  tokenPriceVsQuote?: BigNumber
  poolWeight?: number
  eggPerBlock?: number
  controllerFee?: string
  platformFee?: string
  buybackRate?: string
  withdrawalRate?: string
  entranceFee?: string
  withdrawFee?: string
  venusApy?: string
  annualBurn?: string
  userData?: {
    allowance: BigNumber
    tokenBalance: BigNumber
    stakedBalance: BigNumber
    earnings: BigNumber
  }
  externalApy?: string
  apy?: BigNumber
  extApy?: BigNumber
  totalValue?: BigNumber
  userTvl?: BigNumber
}


export interface Pool extends PoolConfig {
  totalStaked?: BigNumber
  startBlock?: number
  endBlock?: number
  userData?: {
    allowance: BigNumber
    stakingTokenBalance: BigNumber
    stakedBalance: BigNumber
    pendingReward: BigNumber
  }
}

// Slices states

export interface FarmsState {
  data: Farm[]
}

export interface AutoFarmsState {
  data: AutoFarm[]
}


export interface PoolsState {
  data: Pool[]
}

// Global state

export interface State {
  farms: FarmsState
  pools: PoolsState
  autoFarms: AutoFarmsState
}
