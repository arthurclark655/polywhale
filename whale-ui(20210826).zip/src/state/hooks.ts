import BigNumber from 'bignumber.js'
import { useEffect, useMemo } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import useRefresh from 'hooks/useRefresh'
import { fetchFarmsPublicDataAsync, fetchPoolsPublicDataAsync, fetchPoolsUserDataAsync, fetchAutoFarmsPublicDataAsync } from './actions'
import { State, Farm, Pool, AutoFarm } from './types'
import { QuoteToken } from '../config/constants/types'

const ZERO = new BigNumber(0)

export const useFetchPublicData = () => {
  const dispatch = useDispatch()
  const { slowRefresh } = useRefresh()
  useEffect(() => {
    dispatch(fetchFarmsPublicDataAsync())
    dispatch(fetchAutoFarmsPublicDataAsync())
    // dispatch(fetchPoolsPublicDataAsync())
  }, [dispatch, slowRefresh])
}

// Farms

export const useFarms = (): Farm[] => {
  const farms = useSelector((state: State) => state.farms.data)
  return farms
}

export const useFarmFromPid = (pid): Farm => {
  const farm = useSelector((state: State) => state.farms.data.find((f) => f.pid === pid))
  return farm
}

export const useFarmFromSymbol = (lpSymbol: string): Farm => {
  const farm = useSelector((state: State) => state.farms.data.find((f) => f.lpSymbol === lpSymbol))
  return farm
}

export const useFarmUser = (pid) => {
  const farm = useFarmFromPid(pid)

  return {
    allowance: farm.userData ? new BigNumber(farm.userData.allowance) : new BigNumber(0),
    tokenBalance: farm.userData ? new BigNumber(farm.userData.tokenBalance) : new BigNumber(0),
    stakedBalance: farm.userData ? new BigNumber(farm.userData.stakedBalance) : new BigNumber(0),
    earnings: farm.userData ? new BigNumber(farm.userData.earnings) : new BigNumber(0),
  }
}

// AutoFarms

export const useAutoFarms = (): AutoFarm[] => {
  const autofarms = useSelector((state: State) => state.autoFarms.data)
  return autofarms
}

export const useAutoFarmFromPid = (pid): AutoFarm => {
  const autofarm = useSelector((state: State) => state.autoFarms.data.find((f) => f.pid === pid))
  return autofarm
}

export const useAutoFarmFromSymbol = (lpSymbol: string): AutoFarm => {
  const autofarm = useSelector((state: State) => state.autoFarms.data.find((f) => f.lpSymbol === lpSymbol))
  return autofarm
}

export const useAutoFarmUser = (pid) => {
  const autofarm = useAutoFarmFromPid(pid)

  return {
    allowance: autofarm.userData ? new BigNumber(autofarm.userData.allowance) : new BigNumber(0),
    tokenBalance: autofarm.userData ? new BigNumber(autofarm.userData.tokenBalance) : new BigNumber(0),
    stakedBalance: autofarm.userData ? new BigNumber(autofarm.userData.stakedBalance) : new BigNumber(0),
    earnings: autofarm.userData ? new BigNumber(autofarm.userData.earnings) : new BigNumber(0),
  }
}

// Pools

export const usePools = (account): Pool[] => {
  const { fastRefresh } = useRefresh()
  const dispatch = useDispatch()
  useEffect(() => {
    if (account) {
      dispatch(fetchPoolsUserDataAsync(account))
    }
  }, [account, dispatch, fastRefresh])

  const pools = useSelector((state: State) => state.pools.data)
  return pools
}

export const usePoolFromPid = (sousId): Pool => {
  const pool = useSelector((state: State) => state.pools.data.find((p) => p.sousId === sousId))
  return pool
}

// Prices

export const usePriceBnbBusd = (): BigNumber => {
  const pid = 8 // BUSD-BNB LP
  const farm = useFarmFromPid(pid)
  return farm.tokenPriceVsQuote ? new BigNumber(farm.tokenPriceVsQuote) : ZERO
}



export const usePriceEthBusd = (): BigNumber => {
  const pid = 1 // USDC-ETH LP
  const farm = useAutoFarmFromPid(pid)
  return farm.tokenPriceVsQuote ? new BigNumber(farm.tokenPriceVsQuote) : ZERO
}

export const usePriceCakeBusd = (): BigNumber => {
  const pid = 0; // EGG-BUSD LP
  const farm = useFarmFromPid(pid);
  return farm.tokenPriceVsQuote ? new BigNumber(farm.tokenPriceVsQuote) : ZERO;
}

export const usePriceQuickBusd = (): BigNumber => {
  const pid = 4; // EGG-BUSD LP
  const farm = useFarmFromPid(pid);
  return farm.tokenPriceVsQuote ? new BigNumber(farm.tokenPriceVsQuote) : ZERO;
}

export const useTotalValue = (): BigNumber => {
  const farms = useFarms();
  const autoFarms = useAutoFarms()
  const bnbPrice = usePriceBnbBusd();
  const ethPrice = usePriceEthBusd();
  const cakePrice = usePriceCakeBusd();
  let value = new BigNumber(0);
  for (let i = 0; i < farms.length; i++) {
    const farm = farms[i]
    if (farm.lpTotalInQuoteToken) {
      let val;
      if (farm.quoteTokenSymbol === QuoteToken.BNB) {
        val = (bnbPrice.times(farm.lpTotalInQuoteToken));
      }else if (farm.quoteTokenSymbol === QuoteToken.CAKE) {
        val = (cakePrice.times(farm.lpTotalInQuoteToken));
      }else{
        val = (farm.lpTotalInQuoteToken);
      }
      value = value.plus(val);
    }
  }
  for (let i = 0; i < autoFarms.length; i++) {
    const autoFarm = autoFarms[i]
    if (autoFarm.lpTotalInQuoteToken) {
      let val
      // if (autoFarm.quoteTokenSymbol === QuoteToken.BNB) {
      //   val = bnbPrice.times(autoFarm.lpTotalInQuoteToken)
      // } 
      if (autoFarm.quoteTokenSymbol === QuoteToken.ETH) {
        val = ethPrice.times(autoFarm.lpTotalInQuoteToken).times(2);
      }
      else if (autoFarm.quoteTokenSymbol === QuoteToken.CAKE) {
        val = cakePrice.times(autoFarm.lpTotalInQuoteToken).times(2)
      } else {
        val = new BigNumber(autoFarm.lpTotalInQuoteToken).times(2)
      }

      if (autoFarm.pid === 5) {
        val = new BigNumber(val).div(10)
      }
      // if (autoFarm.pid === 24 || autoFarm.pid === 31) {
      //   val = val.times(1000000000000).div(2)
      // }

      // if (autoFarm.pid === 23 || autoFarm.pid === 32) {
      //   val = val.div(2)
      // }

      value = value.plus(val)
    }
  }
  return value;
}

export const useTotalReefValue = (krillMode): BigNumber => {
  const autoFarms = useAutoFarms()
  const bnbPrice = usePriceBnbBusd();
  const ethPrice = usePriceEthBusd();
  const cakePrice = usePriceCakeBusd();
  let value = new BigNumber(0);
  const activeFarms = autoFarms.filter((farm) => !!farm.isKRILLPool === !!krillMode)
  for (let i = 0; i < activeFarms.length; i++) {
    const autoFarm = activeFarms[i]
    if (autoFarm.lpTotalInQuoteToken) {
      let val
      // if (autoFarm.quoteTokenSymbol === QuoteToken.BNB) {
      //   val = bnbPrice.times(autoFarm.lpTotalInQuoteToken)
      // } 
      if (autoFarm.quoteTokenSymbol === QuoteToken.ETH) {
        val = ethPrice.times(autoFarm.lpTotalInQuoteToken).times(2);
      }
      else if (autoFarm.quoteTokenSymbol === QuoteToken.CAKE) {
        val = cakePrice.times(autoFarm.lpTotalInQuoteToken).times(2)
      } else {
        val = new BigNumber(autoFarm.lpTotalInQuoteToken).times(2)
      }

      if (autoFarm.pid === 5) {
        val = new BigNumber(val).div(10)
      }

      // if (autoFarm.pid === 24 || autoFarm.pid === 28) {
      //   val = val.times(1000000000000).div(2)
      // }

      // if (autoFarm.pid === 23 || autoFarm.pid === 32) {
      //   val = val.div(2)
      // }
      value = value.plus(val)
    }
  }
  return value;
}