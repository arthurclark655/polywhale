/* eslint-disable no-param-reassign */
import { createSlice } from '@reduxjs/toolkit'
import autoFarmsConfig from 'config/constants/autoFarms'
import fetchAutoFarms from './fetchAutoFarms'
import {
  fetchFarmUserEarnings,
  fetchFarmUserAllowances,
  fetchFarmUserTokenBalances,
  fetchFarmUserStakedBalances,
} from './fetchAutoFarmUser'
import { AutoFarmsState, AutoFarm } from '../types'

const initialState: AutoFarmsState = { data: [...autoFarmsConfig] }

export const autoFarmsSlice = createSlice({
  name: 'AutoFarms',
  initialState,
  reducers: {
    setAutoFarmsPublicData: (state, action) => {
      const liveFarmsData: AutoFarm[] = action.payload
      state.data = state.data.map((farm) => {
        const liveFarmData = liveFarmsData.find((f) => f.pid === farm.pid)
        return { ...farm, ...liveFarmData }
      })
    },
    setAutoFarmUserData: (state, action) => {
      const { arrayOfUserDataObjects } = action.payload
      arrayOfUserDataObjects.forEach((userDataEl) => {
        const { index } = userDataEl
        state.data[index] = { ...state.data[index], userData: userDataEl }
      })
    },
  },
})

// Actions
export const { setAutoFarmsPublicData, setAutoFarmUserData } = autoFarmsSlice.actions

// Thunks
export const fetchAutoFarmsPublicDataAsync = () => async (dispatch) => {
  const farms = await fetchAutoFarms()
  dispatch(setAutoFarmsPublicData(farms))
}
export const fetchAutoFarmUserDataAsync = (account) => async (dispatch) => {
  const userFarmAllowances = await fetchFarmUserAllowances(account)
  const userFarmTokenBalances = await fetchFarmUserTokenBalances(account)
  const userStakedBalances = await fetchFarmUserStakedBalances(account)
  const userFarmEarnings = await fetchFarmUserEarnings(account)

  const arrayOfUserDataObjects = userFarmAllowances.map((farmAllowance, index) => {
    return {
      index,
      allowance: userFarmAllowances[index],
      tokenBalance: userFarmTokenBalances[index],
      stakedBalance: userStakedBalances[index],
      earnings: userFarmEarnings[index],
    }
  })

  dispatch(setAutoFarmUserData({ arrayOfUserDataObjects }))
}

export default autoFarmsSlice.reducer
