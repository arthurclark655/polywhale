import BigNumber from 'bignumber.js'
import erc20 from 'config/abi/erc20.json'
import iStakingRewards from 'config/abi/iStakingRewards.json'
import autoFarm from 'config/abi/autoFarm.json'
import autoFarmStrat from 'config/abi/autoFarmStrat.json'
import multicall from 'utils/multicall'
import { getAutoFarmAddress } from 'utils/addressHelpers'
import autoFarmsConfig from 'config/constants/autoFarms'
import { QuoteToken } from '../../config/constants/types'

const CHAIN_ID = process.env.REACT_APP_CHAIN_ID


const fetchAutoFarms = async () => {
  
  let baseAPY
  let xvsAPY
  let combinedAPY
  let feeCalc
  let feeAPY
  let supplyVenusApy
  let tokenPrice
  let annualBurn
  let preFeeSupplyVenusApy
  let externalApyCall

  const data = await Promise.all(
    autoFarmsConfig.map(async (farmConfig) => {
      const lpAdress = farmConfig.lpAddresses[CHAIN_ID]
      const calls = [
        // Balance of token in the LP contract
        {
          address: farmConfig.tokenAddresses[CHAIN_ID],
          name: 'balanceOf',
          params: [lpAdress],
        },
        // Balance of quote token on LP contract
        {
          address: farmConfig.quoteTokenAdresses[CHAIN_ID],
          name: 'balanceOf',
          params: [lpAdress],
        },
        // Balance of LP tokens in the master chef contract
        // {
        //   address: farmConfig.isTokenOnly ? farmConfig.tokenAddresses[CHAIN_ID] : lpAdress,
        //   name: 'balanceOf',
        //   params: [getAutoFarmAddress()],
        // },
        // Total supply of LP tokens
        {
          address: lpAdress,
          name: 'totalSupply',
        },
        // Token decimals
        {
          address: farmConfig.tokenAddresses[CHAIN_ID],
          name: 'decimals',
        },
        // Quote token decimals
        {
          address: farmConfig.quoteTokenAdresses[CHAIN_ID],
          name: 'decimals',
        },

      ]

      const [
        tokenBalanceLP,
        quoteTokenBlanceLP,
        // lpTokenBalanceMC,
        lpTotalSupply,
        tokenDecimals,
        quoteTokenDecimals,
      ] = await multicall(erc20, calls)


      const stratAdress = farmConfig.strategyAddress[CHAIN_ID]

      const stratCalls = [
        // Balance of token in the LP contract
        {
          address: stratAdress,
          name: 'tokenLockedTotal',
        },
      ]

      const [
        lpTokenBalanceMC,
      ] = await multicall(autoFarmStrat, stratCalls)


      let qsTokenBalanceMC
      if (farmConfig.pid === 23 || farmConfig.pid === 24 || farmConfig.pid === 25 || farmConfig.pid === 31 || farmConfig.pid === 32) {

        const checkQS = [
          {
          // Balance of token in the LP contract
          address: lpAdress,
          name: 'balanceOf',
          params: [farmConfig.qsStakingAddress[CHAIN_ID]],
          }
        ]

        qsTokenBalanceMC = await multicall(erc20, checkQS)
      }

      let tokenAmount
      let tokenAmount2
      let lpTotalInQuoteToken
      let lpLiqCalc
      let tokenPriceVsQuote
      let qsRewards

      if (farmConfig.isTokenOnly) {
        tokenAmount = new BigNumber(lpTokenBalanceMC).div(new BigNumber(10).pow(tokenDecimals))
        if (farmConfig.tokenSymbol === QuoteToken.BUSD && farmConfig.quoteTokenSymbol === QuoteToken.BUSD) {
          tokenPriceVsQuote = new BigNumber(1)
        } else {
          tokenPriceVsQuote = new BigNumber(quoteTokenBlanceLP).div(new BigNumber(tokenBalanceLP))
        }
        lpTotalInQuoteToken = tokenAmount.times(tokenPriceVsQuote)
      } else {
        // Ratio in % a LP tokens that are in staking, vs the total number in circulation
        const lpTokenRatio = new BigNumber(lpTokenBalanceMC).div(new BigNumber(lpTotalSupply))

        // Total value in staking in quote token value
        lpTotalInQuoteToken = new BigNumber(quoteTokenBlanceLP)
          .div(new BigNumber(10).pow(18))
          .times(new BigNumber(2))
          .times(lpTokenRatio)

        // Amount of token in the LP that are considered staking (i.e amount of token * lp ratio)
        tokenAmount = new BigNumber(tokenBalanceLP).div(new BigNumber(10).pow(tokenDecimals)).times(lpTokenRatio)
        const quoteTokenAmount = new BigNumber(quoteTokenBlanceLP)
          .div(new BigNumber(10).pow(quoteTokenDecimals))
          .times(lpTokenRatio)


        if (tokenAmount.comparedTo(0) > 0) {
          tokenPriceVsQuote = quoteTokenAmount.div(tokenAmount)
        } else if (farmConfig.pid === 2) {
          tokenPriceVsQuote = (new BigNumber(quoteTokenBlanceLP).div(new BigNumber(tokenBalanceLP))).times(1000000000000)
        } else {
          tokenPriceVsQuote = new BigNumber(quoteTokenBlanceLP).div(new BigNumber(tokenBalanceLP))
        }

        lpTotalInQuoteToken = new BigNumber(tokenPriceVsQuote*tokenAmount)

      }


      if (farmConfig.pid === 23 || farmConfig.pid === 24 || farmConfig.pid === 25 || farmConfig.pid === 31 || farmConfig.pid === 32) {
        // Ratio in % a LP tokens that are in staking, vs the total number in circulation
        const lpTokenRatio = new BigNumber(qsTokenBalanceMC).div(new BigNumber(lpTotalSupply))

        // // Total value in staking in quote token value
        // lpTotalInQuoteToken = new BigNumber(quoteTokenBlanceLP)
        //   .div(new BigNumber(10).pow(18))
        //   .times(new BigNumber(2))
        //   .times(lpTokenRatio)

        // Amount of token in the LP that are considered staking (i.e amount of token * lp ratio)
        tokenAmount2 = new BigNumber(tokenBalanceLP).div(new BigNumber(10).pow(tokenDecimals)).times(lpTokenRatio)
        const quoteTokenAmount = new BigNumber(quoteTokenBlanceLP)
          .div(new BigNumber(10).pow(quoteTokenDecimals))
          .times(lpTokenRatio)

        let tokenPriceVsQuote2
        if (tokenAmount2.comparedTo(0) > 0) {
          tokenPriceVsQuote2 = quoteTokenAmount.div(tokenAmount2)
        } else {
          tokenPriceVsQuote2 = new BigNumber(quoteTokenBlanceLP).div(new BigNumber(tokenBalanceLP))
        }

        
        lpLiqCalc = new BigNumber(tokenPriceVsQuote2*tokenAmount2)

      }


      const [info, totalAllocPoint, eggPerBlock] = await multicall(autoFarm, [
        {
          address: getAutoFarmAddress(),
          name: 'poolInfo',
          params: [farmConfig.pid],
        },
        {
          address: getAutoFarmAddress(),
          name: 'totalAllocPoint',
        },
        {
          address: getAutoFarmAddress(),
          name: 'KRILLPerBlock',
        },
      ])

      const allocPoint = new BigNumber(info.allocPoint._hex)
      const poolWeight = allocPoint.div(new BigNumber(totalAllocPoint))
      // allocPoint = allocPoint.div(new BigNumber('1000000000000000000'))
      const [controllerFee, controllerFeeMax, buyBackRate, buyBackRateMax, entranceFeeFactor, entranceFeeFactorMax, withdrawFeeFactor, withdrawFeeFactorMax] = await multicall(autoFarmStrat, [
        {
          address: farmConfig.strategyAddress[CHAIN_ID],
          name: 'getPerformanceFee',
        },
        {
          address: farmConfig.strategyAddress[CHAIN_ID],
          name: 'performanceFeeMax',
        },
        {
          address: farmConfig.strategyAddress[CHAIN_ID],
          name: 'getPerformanceFee',
        },
        {
          address: farmConfig.strategyAddress[CHAIN_ID],
          name: 'performanceFeeMax',
        },
        {
          address: farmConfig.strategyAddress[CHAIN_ID],
          name: 'entranceFee',
        },
        {
          address: farmConfig.strategyAddress[CHAIN_ID],
          name: 'entranceFeeMax',
        },
        {
          address: farmConfig.strategyAddress[CHAIN_ID],
          name: 'withdrawFee',
        },
        {
          address: farmConfig.strategyAddress[CHAIN_ID],
          name: 'withdrawFeeMax',
        },
      ])

      const tempBuyBack = new BigNumber(buyBackRate)
      const tempMax = new BigNumber(buyBackRateMax)

      let currentRate = tempBuyBack.div(tempMax).toNumber()
      currentRate *= 100

      const tempWithdraw = new BigNumber(withdrawFeeFactor)
      const tempWithdrawMax = new BigNumber(withdrawFeeFactorMax)

      let currentWithdrawalFee = tempWithdraw.div(tempWithdrawMax).toNumber()
      currentWithdrawalFee *= 100

      const tempController = new BigNumber(controllerFee)
      const tempControllerMax = new BigNumber(controllerFeeMax)

      let currentControllerFee = tempController.div(tempControllerMax).toNumber()
      currentControllerFee *= 100

      const tempEntrance = new BigNumber(entranceFeeFactor)
      const tempEntranceMax = new BigNumber(entranceFeeFactorMax)

      let currentEntranceFee = tempEntrance.div(tempEntranceMax).toNumber()
      currentEntranceFee *= 100
      currentEntranceFee = 100 - currentEntranceFee

      let liquidity
      let volumeUSD

      if(farmConfig.stratType === 'quickswap') {

        let qsPrice

        const externalFarmCalls = [
          // Balance of token in the fucking base contract for what we are farming (e.g cake/swipeswap)
          {
            address: farmConfig.qsStakingAddress[CHAIN_ID],
            name: 'rewardRate',
          },
        ]

        const [
          rewardRate,
        ] = await multicall(iStakingRewards, externalFarmCalls)

          const qsPriceInfo = await fetch("https://api.coingecko.com/api/v3/coins/quick")
            .then(res => res.json())
            .then(
              (apiResult) => {
                qsPrice = apiResult.market_data.current_price.usd
              }
            )
          
            const rewRate = (rewardRate*86400)/1000000000000000000
            qsRewards = rewRate*qsPrice


          const qsPairInfo = await fetch("https://api.thegraph.com/subgraphs/name/sameepsi/quickswap06"
          ,
          {
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json'
            },
            method: "POST",
            body: JSON.stringify(
              {"operationName":"pairDayDatas","variables":{"pairAddress":farmConfig.lpAddresses[CHAIN_ID],"skip":0},"query":"query pairDayDatas($pairAddress: Bytes!, $skip: Int!) {\n  pairDayDatas(first: 1000, skip: $skip, orderBy: date, orderDirection: asc, where: {pairAddress: $pairAddress}) {\n    id\n    date\n    dailyVolumeToken0\n    dailyVolumeToken1\n    dailyVolumeUSD\n    reserveUSD\n    __typename\n  }\n}\n"}            )
            }
          )
          .then(res => res.json())
          .then(
            (infoResult) => {
              const array = infoResult.data.pairDayDatas
              const pairData = array[array.length - 2]
              const dailyVolume = pairData.dailyVolumeUSD
              const pairData2 = array[array.length - 1]
              liquidity = (farmConfig.pid === 24 || farmConfig.pid === 25 || farmConfig.pid === 31) ? lpLiqCalc.toString() : pairData2.reserveUSD*0.98
              let fees = (dailyVolume*0.0025)
              if (farmConfig.pid === 24 || farmConfig.pid === 31) {
                liquidity *= 2
                const totalFeeSplit = (liquidity/pairData2.reserveUSD)
                fees *= totalFeeSplit
              }
              const totalRewards = (fees + qsRewards)*365
              const apr = (totalRewards / liquidity)
              // if (farmConfig.pid === 14) {
              //   apr /= 2
              // }
              const apy = (1 + apr/8760)**8760 - 1
              const feeApy = apy*(currentRate/100)
              annualBurn = (feeCalc/100)*(tokenAmount*tokenPrice)
              externalApyCall = feeApy
            })

      }

      if (farmConfig.stratType === 'sushi') {
        const farmPair = farmConfig.lpAddresses[CHAIN_ID]

        const pairInfo = await fetch("https://api.thegraph.com/subgraphs/name/sushiswap/matic-exchange"
        ,
        {
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          },
          method: "POST",
          body: JSON.stringify(
            // {"operationName":"pairSubsetQuery","variables":{"first":1000,"orderBy":"timestamp","orderDirection":"desc","pairAddresses":["0x2813d43463c374a680f235c428fb1d7f08de0b69","0x34965ba0ac2451a34a0471f04cca3f990b8dea27","0x497c2cbad454952b20ab66a1a17dac0999ba228e","0x6ff62bfb8c12109e8000935a6de54dad83a4f39f","0xc2755915a85c6f6c1c0f3a86ac8c058f11caa9c9","0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e","0xe62ec2e799305e0d367b0cc3ee2cda135bf89816","0x74d23f21f780ca26b47db16b0504f2e3832b9321","0x4b1f1e2435a9c96f7330faea190ef6a7c8d70001","0x396e655c309676caf0acf4607a868e0cded876db"]},"query":"query pairSubsetQuery($first: Int! = 1000, $pairAddresses: [Bytes]!, $orderBy: String! = \"trackedReserveETH\", $orderDirection: String! = \"desc\") {\n  pairs(first: $first, orderBy: $orderBy, orderDirection: $orderDirection, where: {id_in: $pairAddresses}) {\n    ...pairFields\n    __typename\n  }\n}\n\nfragment pairFields on Pair {\n  id\n  reserveUSD\n  reserveETH\n  volumeUSD\n  untrackedVolumeUSD\n  trackedReserveETH\n  token0 {\n    ...pairTokenFields\n    __typename\n  }\n  token1 {\n    ...pairTokenFields\n    __typename\n  }\n  reserve0\n  reserve1\n  token0Price\n  token1Price\n  totalSupply\n  txCount\n  timestamp\n  __typename\n}\n\nfragment pairTokenFields on Token {\n  id\n  name\n  symbol\n  totalSupply\n  derivedETH\n  __typename\n}\n"}
            {"operationName":"pairDayDatasQuery","variables":{"first":1000,"date":0,"pairs":[farmConfig.lpAddresses[CHAIN_ID]]},"query":"query pairDayDatasQuery($first: Int = 1000, $date: Int = 0, $pairs: [Bytes]!) {\n  pairDayDatas(first: $first, orderBy: date, orderDirection: desc, where: {pair_in: $pairs, date_gt: $date}) {\n    date\n    pair {\n      id\n      __typename\n    }\n    token0 {\n      derivedETH\n      __typename\n    }\n    token1 {\n      derivedETH\n      __typename\n    }\n    reserveUSD\n    volumeToken0\n    volumeToken1\n    volumeUSD\n    txCount\n    __typename\n  }\n}\n"}
            )
        }
        )
        .then(res => res.json())
        .then(
          (infoResult) => {
            // const pairData = infoResult.data.pairs.find(lpPair => lpPair.id === farmPair)
            const pairData = infoResult.data.pairDayDatas[1]
            liquidity = pairData.reserveUSD
            volumeUSD = pairData.volumeUSD
          })

        let maticPrice
        let sushiPrice

        const price = await fetch("https://api.thegraph.com/subgraphs/name/sushiswap/matic-exchange"
        ,
        {
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          },
          method: "POST",
          body: JSON.stringify(
            {"operationName":"tokenDayDatasQuery","variables":{"first":1000,"date":0,"tokens":["0x0b3f868e0be5597d5db7feb59e1cadbb0fdda50a","0x0d500b1d8e8ef31e21c99d1db9a6444d3adf1270"]},"query":"query tokenDayDatasQuery($first: Int! = 1000, $tokens: [Bytes]!, $date: Int! = 0) {\n  tokenDayDatas(first: $first, orderBy: date, orderDirection: desc, where: {token_in: $tokens, date_gt: $date}) {\n    id\n    date\n    token {\n      id\n      __typename\n    }\n    volumeUSD\n    liquidityUSD\n    priceUSD\n    txCount\n    __typename\n  }\n}\n"}
          )
        }
        )
        .then(res => res.json())
        .then(
          (priceResult) => {
            maticPrice = priceResult.data.tokenDayDatas[0].priceUSD
            sushiPrice = priceResult.data.tokenDayDatas[1].priceUSD
          })

      
      const api = await fetch("https://api.thegraph.com/subgraphs/name/sushiswap/matic-minichef"
      ,
      {
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        method: "POST",
        body: JSON.stringify(
          {"operationName":"poolsQuery","variables":{"first":1000,"skip":0,"orderBy":"timestamp","orderDirection":"desc"},"query":"query poolsQuery($first: Int! = 1000, $skip: Int! = 0, $orderBy: String! = \"timestamp\", $orderDirection: String! = \"desc\") {\n  pools(first: $first, skip: $skip, orderBy: $orderBy, orderDirection: $orderDirection) {\n    id\n    pair\n    rewarder {\n      id\n      rewardToken\n      rewardPerSecond\n      __typename\n    }\n    allocPoint\n    lastRewardTime\n    accSushiPerShare\n    slpBalance\n    userCount\n    miniChef {\n      id\n      sushiPerSecond\n      totalAllocPoint\n      __typename\n    }\n    __typename\n  }\n}\n"}
        )
      }
      )
      .then(res => res.json())
      .then(
        (result) => {
          const pairData = result.data.pools.find(lpPair => lpPair.pair === farmPair)

          const sushiRewards = pairData.miniChef.sushiPerSecond
          const maticRewards = pairData.rewarder.rewardPerSecond

          const poolWeight3 = pairData.miniChef.totalAllocPoint
          const poolWeight2 = pairData.allocPoint

          const reward = new BigNumber(sushiRewards).times(new BigNumber(poolWeight2)).div(new BigNumber(10).pow(18))
          
          const dailySushi = sushiRewards/1000000000000000000000 * 86400 * poolWeight2
          const dailyMatic = maticRewards/1000000000000000000000 * 86400 * poolWeight2

          const usdSushiRewards = dailySushi * sushiPrice
          const usdMaticRewards = dailyMatic * maticPrice

          const tradingFees = ((volumeUSD*0.0025))

          const totalRewards = (usdSushiRewards + usdMaticRewards + tradingFees)*365

          const apr = (totalRewards / liquidity)
          const apy = (1 + apr/8760)**8760 - 1
          const feeApy = apy*(currentRate/100)
          annualBurn = (feeCalc/100)*(tokenAmount*tokenPrice)
          externalApyCall = feeApy
        }
      )
    }


      return {
        ...farmConfig,
        tokenAmount: tokenAmount.toJSON(),
        // quoteTokenAmount: quoteTokenAmount,
        lpTotalInQuoteToken: lpTotalInQuoteToken.toJSON(),
        lpTotalInMC: lpTokenBalanceMC.toString(),
        tokenPriceVsQuote: (farmConfig.stratType === 'sushi' || farmConfig.stratType === 'quickswap') ? tokenPriceVsQuote.toString() : tokenPrice.toString(),
        poolWeight: poolWeight.toNumber(),
        multiplier: `${allocPoint.div(1).toString()}X`,
        eggPerBlock: new BigNumber(eggPerBlock).toNumber(),
        buyBackRate: currentRate.toString(),
        withdrawFee: currentWithdrawalFee.toString(),
        controllerFee: currentControllerFee.toString(),
        entranceFee: currentEntranceFee.toString(),
        venusApy: (farmConfig.stratType === 'sushi' || farmConfig.stratType === 'quickswap') ? null : supplyVenusApy.toString(),
        annualBurn: (farmConfig.stratType === 'sushi' || farmConfig.stratType === 'quickswap') ? annualBurn.toString() : annualBurn.toString(),
        externalApy: (farmConfig.stratType === 'sushi' || farmConfig.stratType === 'quickswap') ? externalApyCall.toString() : externalApyCall.toString()
      }
    }),
  )
  return data
}

export default fetchAutoFarms
