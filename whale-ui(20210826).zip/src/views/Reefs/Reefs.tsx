import React, { useEffect, useCallback, useState } from 'react'
import { Route, useRouteMatch } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import BigNumber from 'bignumber.js'
import styled from 'styled-components'
import { useWallet } from '@binance-chain/bsc-use-wallet'
import { provider } from 'web3-core'
import { Image, Heading, RowType, Toggle, Text } from '@pancakeswap-libs/uikit'
import { BLOCKS_PER_YEAR, CAKE_PER_BLOCK, CAKE_POOL_PID } from 'config'
import FlexLayout from 'components/layout/Flex'
import Page from 'components/layout/Page'
import { useAutoFarms, usePriceBnbBusd, usePriceCakeBusd, usePriceEthBusd } from 'state/hooks'
import { AutoFarm } from 'state/types'
import useRefresh from 'hooks/useRefresh'
import { fetchAutoFarmUserDataAsync } from 'state/actions'
import { QuoteToken } from 'config/constants/types'
import useI18n from 'hooks/useI18n'
import Select, { OptionProps } from 'components/Select/Select'
import { getBalanceNumber } from 'utils/formatBalance'
import FarmCard, { FarmWithStakedValue } from './components/FarmCard/FarmCard'
import Table from './components/FarmTable/FarmTable'
import FarmTabButtons from './components/FarmTabButtons'
import Divider from './components/Divider'
import ToggleView from './components/ToggleView/ToggleView'
import SearchInput from './components/SearchInput'
import { DesktopColumnSchema, ViewMode } from './components/types'
import { RowProps } from './components/FarmTable/Row'
import { useTotalReefValue } from '../../state/hooks'
import CardValue from './components/CardValue'


export interface FarmsProps{
  tokenMode?: boolean
  krillMode?: boolean
}

const ControlContainer = styled.div`
  display: flex;
  width: 100%;
  align-items: center;
  position: relative;

  justify-content: space-between;
  flex-direction: column;
  margin-bottom: 32px;

  ${({ theme }) => theme.mediaQueries.sm} {
    flex-direction: row;
    flex-wrap: wrap;
    padding: 16px 32px;
    margin-bottom: 0;
  }
`

const ToggleWrapper = styled.div`
  display: flex;
  align-items: center;
  margin-left: 10px;

  ${Text} {
    margin-left: 8px;
  }
`

const LabelWrapper = styled.div`
  > ${Text} {
    font-size: 12px;
  }
`

const FilterContainer = styled.div`
  display: flex;
  align-items: center;
  width: 100%;
  padding: 8px 0px;

  ${({ theme }) => theme.mediaQueries.sm} {
    width: auto;
    padding: 0;
  }
`

const ViewControls = styled.div`
  flex-wrap: wrap;
  justify-content: space-between;
  display: flex;
  align-items: center;
  width: 100%;

  > div {
    padding: 8px 0px;
  }

  ${({ theme }) => theme.mediaQueries.sm} {
    justify-content: flex-start;
    width: auto;

    > div {
      padding: 0;
    }
  }
`

const Farms: React.FC<FarmsProps> = (farmsProps) => {
  const { path } = useRouteMatch()
  const TranslateString = useI18n()
  const farmsLP = useAutoFarms()
  const cakePrice = usePriceCakeBusd()
  const bnbPrice = usePriceBnbBusd()
  const ethPrice = usePriceEthBusd()
  const { account, ethereum }: { account: string; ethereum: provider } = useWallet()
  const {tokenMode, krillMode} = farmsProps;
  const [viewMode, setViewMode] = useState(ViewMode.TABLE)
  const [sortOption, setSortOption] = useState('all')
  const [query, setQuery] = useState('')
  const totalReefValue = useTotalReefValue(krillMode);


  const dispatch = useDispatch()
  const { fastRefresh } = useRefresh()
  useEffect(() => { 
    if (account) {
      dispatch(fetchAutoFarmUserDataAsync(account))
    }
  }, [account, dispatch, fastRefresh])


  const [stakedOnly, setStakedOnly] = useState(false)

  // const activeFarms = farmsLP.filter((farm) => farm.multiplier !== '0X' && !!farm.isKRILLPool === !!krillMode)
  // const inactiveFarms = farmsLP.filter((farm) => farm.multiplier === '0X' && farm.isKRILLPool === !!krillMode)

  const activeFarms = farmsLP.filter((farm) => farm.multiplier !== '0X' && farm.isKRILLPool === false)
  const inactiveFarms = farmsLP.filter((farm) => farm.isKRILLPool === true)

  const stakedOnlyFarms = activeFarms.filter(
    (farm) => farm.userData && new BigNumber(farm.userData.stakedBalance).isGreaterThan(0),
  )


  // /!\ This function will be removed soon
  // This function compute the APY for each farm and will be replaced when we have a reliable API
  // to retrieve assets prices against USD
  const farmsList = useCallback(
    (farmsToDisplay, removed: boolean) => {
      let farmsToDisplayWithAPY: AutoFarm[] = farmsToDisplay.map((farm) => {
        const cakeRewardPerBlock = new BigNumber(farm.eggPerBlock || 1).times(new BigNumber(farm.poolWeight)) .div(new BigNumber(10).pow(18))
        const cakeRewardPerYear = cakeRewardPerBlock.times(BLOCKS_PER_YEAR)

        let apy = cakePrice.times(cakeRewardPerYear).times(100);

        let totalValue = new BigNumber(farm.lpTotalInQuoteToken || 0);

        if (farm.quoteTokenSymbol === QuoteToken.BNB) {
          totalValue = totalValue.times(bnbPrice);
        }

        if (farm.quoteTokenSymbol === QuoteToken.ETH) {
          totalValue = totalValue.times(ethPrice);
        }

        if (farm.quoteTokenSymbol === QuoteToken.CAKE) {
          totalValue = totalValue.times(cakePrice).div(2);        
        }

        if (farm.pid === 5) {
          totalValue = totalValue.div(10)
        }

        if (farm.pid === 24 || farm.pid === 31) {
          totalValue = new BigNumber(farm.tokenAmount)
        }
        
        totalValue = totalValue.times(2)

        if (farm.pid === 32 || farm.pid === 23) {
          totalValue = totalValue.times(2)
        }

        if(totalValue.comparedTo(0) > 0 && farm.pid !== 0){
          apy = apy.div(totalValue);
        } else if (farm.pid === 0) {
          apy = apy.div(new BigNumber(farm.lpTotalInQuoteToken).times(2));
        }

        const getValue = (quoteTokenSymbol, bal) => {
          if (quoteTokenSymbol === QuoteToken.BNB) {
            return bnbPrice.times(bal)
          }
          if (quoteTokenSymbol === QuoteToken.CAKE) {
            return cakePrice.times(bal)
          }
          if (farm.quoteTokenSymbol === QuoteToken.ETH) {
            return ethPrice.times(bal);
          }
          return bal
        }

        const userShare = farm.userData ? new BigNumber(farm.userData.stakedBalance).dividedBy(farm.lpTotalInMC) : new BigNumber(0)
        let userTvl = farm.pid === 0 ? userShare.multipliedBy(getValue(farm.quoteTokenSymbol, (farm.lpTotalInQuoteToken*2000000000000))) : userShare.multipliedBy(getValue(farm.quoteTokenSymbol, farm.lpTotalInQuoteToken))

        if ((farm.pid >= 12 && farm.pid <= 20) || farm.pid === 31 || farm.pid === 32 || farm.pid === 23 || farm.pid === 3 || farm.pid === 4 || farm.pid === 1 || farm.pid === 2 || farm.pid === 6 || farm.pid === 11 || farm.pid === 9) {
          userTvl = userTvl.multipliedBy(2)
        }

        if (farm.pid === 5) {
          userTvl = userTvl.div(3)
        }

        // if (farm.pid === 24) {
        //   userTvl = userTvl.multipliedBy(1000000000000)
        // }

        const extApy = farm.externalApy
        if(farm.externalApy > 0) {
          apy = apy.plus(extApy*100)
        }

        // console.log(farm)
        // console.log(farm.pid)
        // console.log(userTvl.toString())

        return { ...farm, apy, extApy, totalValue, userTvl }
      })

      if (query) {
        const lowercaseQuery = query.toLowerCase()
        farmsToDisplayWithAPY = farmsToDisplayWithAPY.filter((farm: AutoFarm) => {
          return farm.lpSymbol.toLowerCase().includes(lowercaseQuery)
        })
      }

      if (sortOption !== 'all') {
        const lowercaseQuery = sortOption.toLowerCase()
        farmsToDisplayWithAPY = farmsToDisplayWithAPY.filter((farm: AutoFarm) => {
          return farm.stratType.toLowerCase().includes(lowercaseQuery)
        })
      }

      function compare( a, b ) {
        if ( a.apy.toNumber() < b.apy.toNumber() ){
          return 1;
        }
        if ( a.apy.toNumber() > b.apy.toNumber() ){
          return -1;
        }
        return 0;
      }
      
      farmsToDisplayWithAPY.sort( compare );


      const rowData = farmsToDisplayWithAPY.map((farm) => {
        // const { token, quoteToken } = farm
        const tokenAddress = farm.tokenAddresses["137"]
        const quoteTokenAddress = farm.quoteTokenAdresses["137"]
        const lpLabel = farm.lpSymbol

        const extApy = (farm.extApy === undefined) ? "0" : farm.extApy.toString()
        const showApy = parseFloat(extApy)*100
        const dispApy = showApy.toFixed(2)
      
      
        const krillApr = (farm.apy.toNumber() - showApy)/100
        const krillAPY = (1 + krillApr/365)**365 - 1
        const krillDisp = (krillAPY*100).toFixed(2)
      
        const totalDisp = parseFloat(krillDisp) + parseFloat(dispApy)

        const row: RowProps = {
          apr: {
            value: (totalDisp > 1000000000) ? "infinity" : totalDisp.toFixed(2),
            multiplier: farm.multiplier,
            lpLabel,
            // tokenAddress,
            // quoteTokenAddress,
            cakePrice,
            originalValue: farm.apy.toNumber(),
          },
          farm: {
            image: farm.lpSymbol.split(' ')[0].toLocaleLowerCase(),
            label: lpLabel,
            pid: farm.pid,
          },
          earned: {
            earnings: farm.userData === undefined ? getBalanceNumber(new BigNumber(0)) : getBalanceNumber(new BigNumber(farm.userData.earnings)),
            pid: farm.pid,
          },
          liquidity: {
            liquidity: (farm.pid === 0) ? new BigNumber(farm.lpTotalInQuoteToken).times(2) : farm.totalValue,
          },
          userLiquidity: {
            liquidity: farm.userTvl,
          },
          multiplier: {
            multiplier: farm.multiplier,
          },
          details: farm,
        }
    
        return row
      })


      if (viewMode === ViewMode.TABLE && rowData.length) {
        const columnSchema = DesktopColumnSchema
  
        const columns = columnSchema.map((column) => ({
          id: column.id,
          name: column.name,
          label: column.label,
          sort: (a: RowType<RowProps>, b: RowType<RowProps>) => {
            switch (column.name) {
              case 'farm':
                return b.id - a.id
              case 'apr':
                if (a.original.apr.value && b.original.apr.value) {
                  return Number(a.original.apr.value) - Number(b.original.apr.value)
                }
  
                return 0
              case 'earned':
                return a.original.earned.earnings - b.original.earned.earnings
              default:
                return 1
            }
          },
          sortable: column.sortable,
        }))
        return <Table data={rowData} columns={columns} userDataReady />
      }
      
      return farmsToDisplayWithAPY.map((farm) => (
        <FarmCard
          key={farm.pid}
          farm={farm}
          removed={removed}
          bnbPrice={bnbPrice}
          cakePrice={cakePrice}
          ethereum={ethereum}
          account={account}
        />
      ))
    },
    [bnbPrice, account, cakePrice, ethereum, viewMode, query, ethPrice, sortOption],
  )


  const handleChangeQuery = (event: React.ChangeEvent<HTMLInputElement>) => {
    setQuery(event.target.value)
  }
  

  const handleSortOptionChange = (option: OptionProps): void => {
    setSortOption(option.value)
  }

  return (
    <Page>
      <Heading as="h1" size="lg" color="primary" mb="50px" style={{ textAlign: 'center' }}>
        Stake tokens with auto-compounding yield
      </Heading>
      <Heading as="h2" color="secondary" mb="50px" style={{ textAlign: 'center' }}>
        Fees will be used to buyback KRILL
      </Heading>
      {/* <Image src="/images/whale/reefBeta.png" alt="illustration" width={4167} height={1042} responsive /> */}
      <br />
      <FarmTabButtons stakedOnly={stakedOnly} setStakedOnly={setStakedOnly}/>
      <ControlContainer>
          <ViewControls>
            {/* <ToggleView viewMode={viewMode} onToggle={(mode: ViewMode) => setViewMode(mode)} /> */}
            <ToggleWrapper>
              <Toggle checked={stakedOnly} onChange={() => setStakedOnly(!stakedOnly)} />
              <Text>Staked only</Text>
            </ToggleWrapper>
          </ViewControls>
          <FilterContainer>
            <LabelWrapper>
              <Text>SOURCE</Text>
              <Select
                options={[
                  {
                    label: 'All',
                    value: 'all',
                  },
                  {
                    label: 'QuickSwap',
                    value: 'quickswap',
                  },
                  {
                    label: 'Sushi',
                    value: 'sushi',
                  },
                ]}
                onChange={handleSortOptionChange}
              />
            </LabelWrapper>
            <LabelWrapper style={{ marginLeft: 16 }}>
              <Text>SEARCH</Text>
              <SearchInput onChange={handleChangeQuery} />
            </LabelWrapper>
          </FilterContainer>
        </ControlContainer>
      <div>
      <CardValue value={totalReefValue.toNumber()} prefix="$" decimals={2}/>
        <Divider />
          <Route exact path={`${path}`}>
          {/* {
            (tokenMode) ? ( <div className="Krill-Countdown">
            <iframe width="269" height="138" src="https://w2.countingdownto.com/3578713" frameBorder="0" title="Krill Staking"/>
          </div>) : null
          } */}
            {stakedOnly ? farmsList(stakedOnlyFarms, false) : farmsList(activeFarms, false)}
          </Route>
          <Route exact path={`${path}/history`}>
            {farmsList(inactiveFarms, true)}
          </Route>
      </div>
      <Image src="/images/whale/8.png" alt="illustration" width={1352} height={587} responsive />
    </Page>
  )
}

export default Farms
