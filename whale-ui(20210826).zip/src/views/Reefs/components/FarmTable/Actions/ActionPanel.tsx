import React from 'react'
import styled, { keyframes, css } from 'styled-components'
import { LinkExternal, Text } from '@pancakeswap-libs/uikit'
import { FarmWithStakedValue } from 'views/Farms/components/FarmCard/FarmCard'
import { AutoFarm } from 'state/types'
import getLiquidityUrlPathParts from 'utils/getLiquidityUrlPathParts'
import { CommunityTag, SushiTag, DualTag } from 'components/Tags'

import HarvestAction from './HarvestAction'
import StakedAction from './StakedAction'
import Apr, { AprProps } from '../Apr'
import Multiplier, { MultiplierProps } from '../Multiplier'
import Liquidity, { LiquidityProps } from '../Liquidity'
import { ActionContainer, ActionTitles, Earned, Title, Subtle } from './styles'

export interface ActionPanelProps {
  apr: AprProps
  multiplier: MultiplierProps
  liquidity: LiquidityProps
  details: AutoFarm
  userDataReady: boolean
  expanded: boolean
}

const expandAnimation = keyframes`
  from {
    max-height: 0px;
  }
  to {
    max-height: 700px;
  }
`

const collapseAnimation = keyframes`
  from {
    max-height: 700px;
  }
  to {
    max-height: 0px;
  }
`

const Container = styled.div<{ expanded }>`
  animation: ${({ expanded }) =>
    expanded
      ? css`
          ${expandAnimation} 300ms linear forwards
        `
      : css`
          ${collapseAnimation} 300ms linear forwards
        `};
  overflow: hidden;
  background: ${({ theme }) => theme.colors.background};
  display: flex;
  width: 100%;
  flex-direction: column-reverse;
  padding: 24px;
  flex-basis: 100%;

  ${({ theme }) => theme.mediaQueries.lg} {
    flex-direction: column-reverse;
    padding: 16px 32px;
  }
`

const StyledLinkExternal = styled(LinkExternal)`
  font-weight: 400;
`

const StakeContainer = styled.div`
  color: ${({ theme }) => theme.colors.text};
  align-items: center;
  display: flex;
  justify-content: space-between;

  ${({ theme }) => theme.mediaQueries.sm} {
    justify-content: flex-start;
  }
`

const TagsContainer = styled.div`
  display: flex;
  align-items: center;
  margin-top: 25px;

  ${({ theme }) => theme.mediaQueries.sm} {
    margin-top: 16px;
  }

  > div {
    height: 24px;
    padding: 0 6px;
    font-size: 14px;
    margin-right: 4px;

    svg {
      width: 14px;
    }
  }
`

const ActionContainer2 = styled.div`
  display: flex;
  flex-direction: column;

  ${({ theme }) => theme.mediaQueries.sm} {
    flex-direction: row;
    align-items: center;
    flex-grow: 1;
    flex-basis: 0;
  }
`

const InfoContainer = styled.div`
  min-width: 200px;
  display: flex;
  flex-direction: row;
`

const FeeContainer = styled.div`
  min-width: 70%;
`

const ValueContainer = styled.div`
  display: block;

  ${({ theme }) => theme.mediaQueries.lg} {
    display: none;
  }
`

const ValueWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: 4px 0px;
`

const DetailsContainer = styled.div`
  padding: 16px;
  border: 2px solid ${({ theme }) => theme.colors.input};
  border-radius: 16px;
  flex-grow: 1;
  flex-basis: 0;
  margin-bottom: 16px;
  display: flex;
  justify-content: space-between;
  flex-direction: column;

  ${({ theme }) => theme.mediaQueries.lg} {
    flex-direction: row;
    padding: 16px 32px;
  }

  ${({ theme }) => theme.mediaQueries.sm} {
    margin-left: 12px;
    margin-right: 12px;
    margin-bottom: 0;
    max-height: 100px;
  }

  ${({ theme }) => theme.mediaQueries.xl} {
    margin-left: 48px;
    margin-right: 0;
    margin-bottom: 0;
    max-height: 100px;
  }
`

export const ActionContent = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: left;
  flex-direction: column;
  color: ${({ theme }) => theme.colors.text};
`

const ActionPanel: React.FunctionComponent<ActionPanelProps> = ({
  details,
  apr,
  multiplier,
  liquidity,
  userDataReady,
  expanded,
}) => {
  const farm = details
  const strat = farm.stratType
  const isActive = farm.multiplier !== '0X'
  const { dual } = farm
  const lpLabel = farm.lpSymbol && farm.lpSymbol.toUpperCase().replace('PANCAKE', '')
  // const liquidityUrlPathParts = getLiquidityUrlPathParts({
  //   quoteTokenAddress: farm.quoteTokenAdresses[process.env.REACT_APP_CHAIN_ID],
  //   tokenAddress: farm.tokenAddresses[process.env.REACT_APP_CHAIN_ID],
  // })
  const lpAddress = farm.lpAddresses[process.env.REACT_APP_CHAIN_ID]
  const bsc = `https://explorer-mainnet.maticvigil.com/address/${farm.strategyAddress[process.env.REACT_APP_CHAIN_ID]}`
  const info = strat === 'quickswap' ? `https://info.quickswap.exchange/pair/${lpAddress}` : `https://analytics-polygon.sushi.com/pairs/${lpAddress}`
  const lpLink = strat === 'quickswap' ? 'https://quickswap.exchange/#/add/' : 'https://app.sushi.com/add/'

  const extApy = (farm.extApy === undefined) ? "0" : farm.extApy.toString()
  const showApy = parseFloat(extApy)*100
  const dispApy = showApy.toFixed(2)


  const krillApr = (farm.apy.toNumber() - showApy)/100
  const krillAPY = (1 + krillApr/365)**365 - 1
  const krillDisp = (krillAPY*100).toFixed(2)

  const totalDisp = parseFloat(krillDisp) + parseFloat(dispApy)

  return (
    <Container expanded={expanded}>
        <DetailsContainer>
          <ActionContent>
            <Title>FEES</Title>
            <div>
            Entrance: {farm.entranceFee}% (NFT Reduction 0%)
            <br />
            Withdrawal: {100 - parseFloat(farm.withdrawFee)}% (NFT Reduction 0%)
            <br />
            Profits: {100 - parseFloat(farm.buyBackRate)}% (NFT Reduction 0%)
            </div>
          </ActionContent>
          <ActionContent>
            <Title>APY</Title>
            <div>
            Base: 0%
            <br />
            KRILL: 0%
            <br />
            Total: 0%
            </div>
          </ActionContent>
          <ActionContent>
          <div>
          {isActive && (
            <StakeContainer>
              <StyledLinkExternal href={`${lpLink}${farm.quoteTokenAdresses[process.env.REACT_APP_CHAIN_ID]}/${farm.tokenAddresses[process.env.REACT_APP_CHAIN_ID]}`}>
                Get ${lpLabel}
              </StyledLinkExternal>
            </StakeContainer>
          )}
          <StyledLinkExternal href={bsc}>View Contract</StyledLinkExternal>
          <StyledLinkExternal href={info}>See Pair Info</StyledLinkExternal>
        </div>
          </ActionContent>
        </DetailsContainer>
      <br />
      <ActionContainer2>
        <HarvestAction {...farm} userDataReady={userDataReady} />
        <StakedAction {...farm} userDataReady={userDataReady} />
      </ActionContainer2>

    </Container>
  )
}

export default ActionPanel
