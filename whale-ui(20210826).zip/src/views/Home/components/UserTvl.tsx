import React, { useEffect, useState } from 'react'
import { Card, CardBody, Heading, Text } from '@pancakeswap-libs/uikit'
import BigNumber from 'bignumber.js/bignumber'
import useRefresh from 'hooks/useRefresh'
import { useDispatch } from 'react-redux'
import { useWallet } from '@binance-chain/bsc-use-wallet'
import { provider } from 'web3-core'
import styled from 'styled-components'
import { QuoteToken } from 'config/constants/types'
import { fetchFarmUserDataAsync, fetchPoolsUserDataAsync, fetchAutoFarmUserDataAsync } from 'state/actions'
import { useFarms, usePriceBnbBusd, usePriceCakeBusd, usePriceEthBusd, useAutoFarms } from 'state/hooks'
import { getBalanceNumber } from 'utils/formatBalance'
import useI18n from 'hooks/useI18n'
import CardValue from './CardValue'



const StyledCakeStats = styled(Card)`
  margin-left: auto;
  margin-right: auto;
`

const Row = styled.div`
  align-items: center;
  display: flex;
  font-size: 14px;
  justify-content: space-between;
  margin-bottom: 8px;
`

const UserTvl = () => {
  const { account, ethereum }: { account: string; ethereum: provider } = useWallet()
  const cakePrice = usePriceCakeBusd()
  const bnbPrice = usePriceBnbBusd()
  const ethPrice = usePriceEthBusd()


  const dispatch = useDispatch()
  const { fastRefresh } = useRefresh()
  useEffect(() => {
    if (account) {
      dispatch(fetchAutoFarmUserDataAsync(account))
      dispatch(fetchFarmUserDataAsync(account))
      dispatch(fetchPoolsUserDataAsync(account))
    }
  }, [account, dispatch, fastRefresh])

  const autoFarmsLP = useAutoFarms()
  const farmsLP = useFarms()

  const getValue = (quoteTokenSymbol, bal) => {
    if (quoteTokenSymbol === QuoteToken.BNB) {
      return bnbPrice.times(bal)
    }
    if (quoteTokenSymbol === QuoteToken.CAKE) {
      return cakePrice.times(bal)
    }
    return bal
  }

  // let autoFarms = new BigNumber(0)
  // if(autoFarmsLP) {
  //   const stakedOnlyFarms = autoFarmsLP.filter(
  //     (farm) => farm.userData && new BigNumber(farm.userData.stakedBalance).isGreaterThan(0),
  //   )
  //   stakedOnlyFarms.forEach(farm => {

  //     if(farm.lpTotalInQuoteToken && farm.userData) {
    
  //       const userShare = new BigNumber(farm.userData.stakedBalance).dividedBy(farm.lpTotalInMC)
  //       const lpTotal = farm.lpTotalInQuoteToken.toString()
  //       const calcTotal = farm.pid === 0 ? parseFloat(lpTotal)*2000000000 : lpTotal
  //       autoFarms = farms.plus(userShare.multipliedBy(new BigNumber(getValue(farm.quoteTokenSymbol,lpTotal))))

  //     }

  //   });
  // }

  let farms = new BigNumber(0)
  if(farmsLP) {
    const stakedOnlyFarms = farmsLP.filter(
      (farm) => farm.userData && new BigNumber(farm.userData.stakedBalance).isGreaterThan(0) && !!farm.isTokenOnly === !!false,
    )
    stakedOnlyFarms.forEach(farm => {
      const userShare = new BigNumber(farm.userData.stakedBalance).dividedBy(farm.lpTotalInMC)

      farms = farms.plus(userShare.multipliedBy(getValue(farm.quoteTokenSymbol, farm.lpTotalInQuoteToken)))});
  }
  let nests = new BigNumber(0)
  if(farmsLP) {
    const stakedOnlyFarms = farmsLP.filter(
      (farm) => farm.userData && new BigNumber(farm.userData.stakedBalance).isGreaterThan(0) && !!farm.isTokenOnly === !!true,
    )
    stakedOnlyFarms.forEach(farm => {
      let nest
      if (farm.pid === 999) {
        nest = cakePrice.multipliedBy(farm.userData.stakedBalance);
      } else if (farm.tokenSymbol === 'WBTC') {
          nest = new BigNumber(farm.userData.stakedBalance).div(1000000000).multipliedBy(farm.tokenPriceVsQuote)
      } else if (farm.tokenSymbol === 'YLD') {
        nest = new BigNumber(farm.userData.stakedBalance).div(1000000000000000000).multipliedBy(new BigNumber(farm.tokenPriceVsQuote).multipliedBy(bnbPrice))
      } else {
        nest = new BigNumber(farm.userData.stakedBalance).div(1000000000000000000).multipliedBy(farm.tokenPriceVsQuote)
      }
      nests = nests.plus(nest)
      });
  }

  const totalfarms = farms.toNumber();
  const totalStaked = nests.toNumber();
  // const totalAuto = getBalanceNumber(autoFarms)
  const totalLocked = totalfarms + totalStaked
  return (
    <StyledCakeStats>
      <CardBody>
        <Heading size="xl" mb="24px">
          Your Stats (TVL)
        </Heading>
        <Row> 
          <Text fontSize="14px">Ocean</Text>
          {farms && <CardValue fontSize="14px" value={farms.toNumber()} decimals={0} prefix="$" />}
        </Row>
        <Row> 
          <Text fontSize="14px">Tanks</Text>
          {nests && <CardValue fontSize="14px" value={nests.toNumber()} decimals={0} prefix="$" />}
        </Row>
        {/* <Row>
          <Text fontSize="14px">Reef</Text>
          {autoFarms && <CardValue fontSize="14px" value={getBalanceNumber(autoFarms)} decimals={0} prefix="$" />}
        </Row> */}
        <Row>
          <Text fontSize="24px">Total: </Text>
          {totalLocked && <CardValue fontSize="24px" value={totalLocked} decimals={2} prefix="$" />}
        </Row>
      </CardBody>
    </StyledCakeStats>
  )
}

export default UserTvl
