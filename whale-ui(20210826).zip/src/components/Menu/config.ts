import { MenuEntry } from '@pancakeswap-libs/uikit'

const config: MenuEntry[] = [
  {
    label: 'Home',
    icon: 'HomeIcon',
    href: '/',
  },
  // {
  //   label: 'Trade',
  //   icon: 'TradeIcon',
  //   items: [
  //     {
  //       label: 'Exchange',
  //       href: 'https://exchange.goosedefi.com/',
  //     },
  //     {
  //       label: 'Liquidity',
  //       href: 'https://exchange.goosedefi.com/#/pool',
  //     },
  //   ],
  // },
  {
    label: 'Ocean',
    icon: 'FarmIcon',
    href: '/ocean',
  },
  {
    label: 'Ocean V2',
    icon: 'FarmIcon',
    href: '/oceanV2',
  },
  {
    label: 'Tanks',
    icon: 'GooseIcon',
    href: '/tanks',
  },
  {
    label: 'Reef',
    icon: 'ReefIcon',
    href: '/reef',
  },
  // {
  //   label: 'Gulf Pools',
  //   icon: 'PoolIcon',
  //   href: '/pools',
  // },
  // {
  //   label: 'Vaults',
  //   icon: 'VaultIcon',
  //   href: '/vaults',
  // },
  // {
  //   label: 'Lottery',
  //   icon: 'TicketIcon',
  //   href: '/lottery',
  // },
  // {
  //   label: 'NFT',
  //   icon: 'NftIcon',
  //   href: '/nft',
  // },
  {
    label: 'Info',
    icon: 'InfoIcon',
    items: [
      {
        label: 'QuickSwap Exchange',
        href: 'https://quickswap.exchange/#/swap?outputCurrency=0x05089C9EBFFa4F0AcA269e32056b1b36B37ED71b',
        target: '_blank',
      },
      {
        label: 'QuickSwap Charts',
        href: 'https://info.quickswap.exchange/token/0x05089c9ebffa4f0aca269e32056b1b36b37ed71b',
        target: '_blank',
      },
      {
        label: 'CoinGecko',
        href: 'https://www.coingecko.com/en/coins/polywhale',
        target: '_blank',
      },
      {
        label: 'CoinMarketCap',
        href: 'https://coinmarketcap.com/currencies/krill/',
        target: '_blank',
      },
      {
        label: 'Block Explorer',
        href: 'https://explorer-mainnet.maticvigil.com/',
        target: '_blank',
      },
    ],
  },
  {
    label: 'Docs',
    icon: 'MoreIcon',
    items: [
      {
        label: 'Gitbook',
        href: 'https://app.gitbook.com/@polywhale/s/polywhale/',
        target: '_blank',
      },
      {
        label: 'Medium',
        href: 'https://medium.com/polywhale',
        target: '_blank',
      },
    ],
  },
  {
    label: 'Roadmap',
    icon: 'RoadmapIcon',
    href: 'https://app.gitbook.com/@polywhale/s/polywhale/roadmap',
  },
  {
    label: 'Audit by Hacken',
    icon: 'AuditIcon',
    href: 'https://hacken.io/wp-content/uploads/2021/04/290432021_Polywhale_SC_Audit_Report-v2.pdf',
  },
]

export default config
