import { createGlobalStyle } from 'styled-components'
// eslint-disable-next-line import/no-unresolved
import { PancakeTheme } from '@pancakeswap-libs/uikit'

declare module 'styled-components' {
  /* eslint-disable @typescript-eslint/no-empty-interface */
  export interface DefaultTheme extends PancakeTheme {}
}

const GlobalStyle = createGlobalStyle`
  * {
    font-family: 'Share Tech', sans-serif;
  }
  body {
    background-color: ${({ theme }) => theme.colors.background};
    background-image: url('/images/whale/bg.png');
    background-size: fill;
    ${({ theme }) => theme.mediaQueries.lg} {
      background-image: ${({ theme }) => (theme.isDark ? 'url("/images/whale/sidebarbg.jpg")' :'url("/images/whale/space3.png")')};
      background-size: ${({ theme }) => (theme.isDark ? '60% 70%' :'55%')};
      background-repeat: no-repeat;
      background-position: ${({ theme }) => (theme.isDark ? '64% 70%' :'100% 150%')};
    }
    img {
      height: auto;
      max-width: 100%;
    }
  }

  .locked {
    background-color: #E9EAEB;
    pointer-events: none;
      div {
      color: #BDC2C4;
      }
      svg {
        fill: #BDC2C4;
      }
  }  

  .locked-card {
    opacity: 0.2;
    pointer-events: none;
    .locked-card-icon {
      background-image: url('/images/lock-icon.png');
      background-repeat: no-repeat;
      background-size: 60%;
      background-position: center;
      position: absolute;
      width: 100%;
      height: 100%;
    }
  }

  .Krill-Countdown {
    display: flex;
    justify-content: center;
    margin: auto;
    margin-bottom: 22%;
  }
  
`

export default GlobalStyle
