import contracts from './contracts'
import { AutoFarmConfig, QuoteToken } from './types'

const autoFarms: AutoFarmConfig[] = [
  {
    pid: 0,
    risk: 5,
    isTokenOnly: false,
    isKRILLPool: true,
    lpSymbol: 'WMATIC - WETH',
    lpAddresses: {
      97: '',
      56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', // WMATIC - WETH
      137: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e' // WMATIC - WETH
    },
    tokenSymbol: 'WETH',
    tokenAddresses: {
      97: '',
      56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
      137: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619'
    },
    quoteTokenSymbol: QuoteToken.BNB,
    quoteTokenAdresses: contracts.wbnb,
    stratType: 'sushi',
    strategyAddress: {
      97: '',
      56: '0xA345b3453c6adD921347002a4805f9D4B92f4309', // Strategy contract
      137: '0x2200640e071c24eDaC3a5d67503609eAF690F0B9', // Strategy contract
    },
  },
  {
    pid: 1,
    risk: 5,
    isTokenOnly: false,
    isKRILLPool: true,
    lpSymbol: 'USDC - WETH',
    lpAddresses: {
      97: '',
      56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', 
      137: '0x34965ba0ac2451a34a0471f04cca3f990b8dea27' // USDC - WETH
    },
    tokenSymbol: 'WETH',
    tokenAddresses: {

      
      97: '',
      56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
      137: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619'
    },
    quoteTokenSymbol: QuoteToken.BUSD,
    quoteTokenAdresses: contracts.busd,
    stratType: 'sushi',
    strategyAddress: {
      97: '',
      56: '0x3Bd3F61275dBe855eAc9dFdEb33e3b3Bee1c4450', // Strategy contract
      137: '0x256D00de99fd58BF30A590dfb6004a83a057F713', // Strategy contract
    },
  },
  {
    pid: 2,
    risk: 5,
    isTokenOnly: false,
    isKRILLPool: true,
    lpSymbol: 'USDT - WETH',
    lpAddresses: {
      97: '',
      56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', 
      137: '0xc2755915a85c6f6c1c0f3a86ac8c058f11caa9c9' // USDT - WETH
    },
    tokenSymbol: 'WETH',
    tokenAddresses: {
      97: '',
      56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
      137: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619'
    },
    quoteTokenSymbol: QuoteToken.BUSD,
    quoteTokenAdresses: {
      97: '',
      56: '',
      137: '0xc2132d05d31c914a87c6611c10748aeb04b58e8f'
    },
    stratType: 'sushi',
    strategyAddress: {
      97: '',
      56: '0x32C1B85EF1c26a0C4e47fc1F1be7C214F686b695', // Strategy contract
      137: '0x738E11E2d32ed6344343C869DEc609cFBD44e321', // Strategy contract
    },
  },
  {
    pid: 3,
    risk: 5,
    isTokenOnly: false,
    isKRILLPool: true,
    lpSymbol: 'WBTC - WETH',
    lpAddresses: {
      97: '',
      56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', 
      137: '0xe62ec2e799305e0d367b0cc3ee2cda135bf89816' // WBTC - WETH
    },
    tokenSymbol: 'WBTC',
    tokenAddresses: {
      97: '',
      56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
      137: '0x1bfd67037b42cf73acf2047067bd4f2c47d9bfd6'
    },
    quoteTokenSymbol: QuoteToken.ETH,
    quoteTokenAdresses: contracts.eth,
    stratType: 'sushi',
    strategyAddress: {
      97: '',
      56: '0x0EB45FB99b40210a559c09f2F40b7a478a704bE7', // Strategy contract
      137: '0x7Cb82952668C8BC6F166713cd0da085f90e7FC60', // Strategy contract
    },
  },
  {
    pid: 4,
    risk: 5,
    isTokenOnly: false,
    isKRILLPool: true,
    lpSymbol: 'DAI - WETH',
    lpAddresses: {
      97: '',
      56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', 
      137: '0x6ff62bfb8c12109e8000935a6de54dad83a4f39f' // WBTC - WETH
    },
    tokenSymbol: 'WETH',
    tokenAddresses: {
      97: '',
      56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
      137: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619'
    },
    quoteTokenSymbol: QuoteToken.BUSD,
    quoteTokenAdresses:  {
      97: '',
      56: '',
      137: '0x8f3cf7ad23cd3cadbd9735aff958023239c6a063'
    },
    stratType: 'sushi',
    strategyAddress: {
      97: '',
      56: '0x9298664EE9914812eB9c260F3a4B8E7C633315cf', // Strategy contract
      137: '0x2cb19f8c0ADBf6F36DF6c24d4509e8DAefBDCa99', // Strategy contract
    },
  },
  {
    pid: 5,
    risk: 5,
    isTokenOnly: false,
    isKRILLPool: true,
    lpSymbol: 'AAVE - WETH',
    lpAddresses: {
      97: '',
      56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', 
      137: '0x2813d43463c374a680f235c428fb1d7f08de0b69' // AAVE - WETH
    },
    tokenSymbol: 'WETH',
    tokenAddresses: {
      97: '',
      56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
      137: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619'
    },
    quoteTokenSymbol: QuoteToken.ETH,
    quoteTokenAdresses:  {
      97: '',
      56: '', 
      137: '0xd6df932a45c0f255f85145f286ea0b292b21c90b',
    },
    stratType: 'sushi',
    strategyAddress: {
      97: '',
      56: '0x6bc3b00a49100115e200F324eBC46c35dAD09656', // Strategy contract
      137: '0x8a6Eb6524A58148b17adA6fe99047fA40dbe9818', // Strategy contract
    },
  },
  {
    pid: 6,
    risk: 5,
    isTokenOnly: false,
    isKRILLPool: true,
    lpSymbol: 'LINK - WETH',
    lpAddresses: {
      97: '',
      56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', 
      137: '0x74d23f21f780ca26b47db16b0504f2e3832b9321' // LINK - WETH
    },
    tokenSymbol: 'WETH',
    tokenAddresses: {
      97: '',
      56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
      137: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619'
    },
    quoteTokenSymbol: QuoteToken.ETH,
    quoteTokenAdresses:  {
      97: '',
      56: '', 
      137: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619',
    },
    stratType: 'sushi',
    strategyAddress: {
      97: '',
      56: '', // Strategy contract
      137: '0x405Ed4A29beD5599e5504d913a0f4be4e78Aa72a', // Strategy contract
    },
  },
  // { THIS POOL IS FUCKED 
  //   pid: 7,
  //   risk: 5,
  //   isTokenOnly: false,
  //   lpSymbol: 'USDT - USDC',
  //   lpAddresses: {
  //     97: '',
  //     56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', 
  //     137: '0x4b1f1e2435a9c96f7330faea190ef6a7c8d70001' // USDT - USDC
  //   },
  //   tokenSymbol: 'USDT',
  //   tokenAddresses: {
  //     97: '',
  //     56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
  //     137: '0xc2132d05d31c914a87c6611c10748aeb04b58e8f'
  //   },
  //   quoteTokenSymbol: QuoteToken.BUSD,
  //   quoteTokenAdresses: contracts.busd,
  //   stratType: 'sushi',
  //   strategyAddress: {
  //     97: '',
  //     56: '', // Strategy contract
  //     137: '0xFAa0F1d577Ab3082366eb7d7e740b3E93d0AD81f', // Strategy contract
  //   },
  // },
  // {  FUCKED AGAIN
  //   pid: 8,
  //   risk: 5,
  //   isTokenOnly: false,
  //   lpSymbol: 'USDT - USDC',
  //   lpAddresses: {
  //     97: '',
  //     56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', 
  //     137: '0x4b1f1e2435a9c96f7330faea190ef6a7c8d70001' // USDT - USDC
  //   },
  //   tokenSymbol: 'USDT',
  //   tokenAddresses: {
  //     97: '',
  //     56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
  //     137: '0xc2132d05d31c914a87c6611c10748aeb04b58e8f'
  //   },
  //   quoteTokenSymbol: QuoteToken.BUSD,
  //   quoteTokenAdresses: contracts.busd,
  //   stratType: 'sushi',
  //   strategyAddress: {
  //     97: '',
  //     56: '', // Strategy contract
  //     137: '0xF9B504885403836cB4BDdA0A8cacb7220Fae997d', // Strategy contract
  //   },
  // },
  {
    pid: 9,
    risk: 5,
    isTokenOnly: false,
    isKRILLPool: true,
    lpSymbol: 'USDT - USDC',
    lpAddresses: {
      97: '',
      56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', 
      137: '0x4b1f1e2435a9c96f7330faea190ef6a7c8d70001' // USDT - USDC
    },
    tokenSymbol: 'USDT',
    tokenAddresses: {
      97: '',
      56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
      137: '0xc2132d05d31c914a87c6611c10748aeb04b58e8f'
    },
    quoteTokenSymbol: QuoteToken.BUSD,
    quoteTokenAdresses: contracts.busd,
    stratType: 'sushi',
    strategyAddress: {
      97: '',
      56: '', // Strategy contract
      137: '0xF9B504885403836cB4BDdA0A8cacb7220Fae997d', // Strategy contract
    },
  },
  // {
  //   pid: 10, ANOTHER FUCKED POOL
  //   risk: 5,
  //   isTokenOnly: false,
  //   lpSymbol: 'CRV - WETH',
  //   lpAddresses: {
  //     97: '',
  //     56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', 
  //     137: '0x396e655c309676caf0acf4607a868e0cded876db' // CRV - WETH
  //   },
  //   tokenSymbol: 'WETH',
  //   tokenAddresses: {
  //     97: '',
  //     56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
  //     137: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619'
  //   },
  //   quoteTokenSymbol: QuoteToken.ETH,
  //   quoteTokenAdresses:  {
  //     97: '',
  //     56: '', 
  //     137: '0x172370d5cd63279efa6d502dab29171933a610af',
  //   },
  //   stratType: 'sushi',
  //   strategyAddress: {
  //     97: '',
  //     56: '', // Strategy contract
  //     137: '0x5FD804dA591EC98f9b3CB9b1940A8690b4f976A6', // Strategy contract
  //   },
  // },
  {
    pid: 11,
    risk: 5,
    isTokenOnly: false,
    isKRILLPool: true,
    lpSymbol: 'CRV - WETH',
    lpAddresses: {
      97: '',
      56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', 
      137: '0x396e655c309676caf0acf4607a868e0cded876db' // CRV - WETH
    },
    tokenSymbol: 'WETH',
    tokenAddresses: {
      97: '',
      56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
      137: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619'
    },
    quoteTokenSymbol: QuoteToken.ETH,
    quoteTokenAdresses:  {
      97: '',
      56: '', 
      137: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619',
    },
    stratType: 'sushi',
    strategyAddress: {
      97: '',
      56: '', // Strategy contract
      137: '0x5FD804dA591EC98f9b3CB9b1940A8690b4f976A6', // Strategy contract
    },
  },
  {
    pid: 12,
    risk: 5,
    isTokenOnly: false,
    isKRILLPool: true,
    lpSymbol: 'WMATIC - WETH',
    lpAddresses: {
      97: '',
      56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', 
      137: '0xadbF1854e5883eB8aa7BAf50705338739e558E5b' // WMATIC - WETH
    },
    tokenSymbol: 'WETH',
    tokenAddresses: {
      97: '',
      56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
      137: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619'
    },
    quoteTokenSymbol: QuoteToken.ETH,
    quoteTokenAdresses:  {
      97: '',
      56: '', 
      137: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619',
    },
    stratType: 'quickswap',
    strategyAddress: {
      97: '',
      56: '', // Strategy contract
      137: '0xeB5Ff5A16404C84189aF0d8F7357baAb17976454', // Strategy contract
    },
    qsStakingAddress: {
      97: '',
      56: '',
      137: '0x8FF56b5325446aAe6EfBf006a4C1D88e4935a914'
    },
  },
  {
    pid: 13,
    risk: 5,
    isTokenOnly: false,
    isKRILLPool: true,
    lpSymbol: 'USDT - WETH',
    lpAddresses: {
      97: '',
      56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', 
      137: '0xf6422b997c7f54d1c6a6e103bcb1499eea0a7046' // WMATIC - WETH
    },
    tokenSymbol: 'WETH',
    tokenAddresses: {
      97: '',
      56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
      137: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619'
    },
    quoteTokenSymbol: QuoteToken.ETH,
    quoteTokenAdresses:  {
      97: '',
      56: '', 
      137: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619',
    },
    stratType: 'quickswap',
    strategyAddress: {
      97: '',
      56: '', // Strategy contract
      137: '0xC7f19272Fe88B389A0951D53C8285E2C7fEdAefc', // Strategy contract
    },
    qsStakingAddress: {
      97: '',
      56: '',
      137: '0xB26bfcD52D997211C13aE4C35E82ced65AF32A02'
    },
  },
  {
    pid: 14,
    risk: 5,
    isTokenOnly: false,
    isKRILLPool: true,
    lpSymbol: 'WBTC - WETH',
    lpAddresses: {
      97: '',
      56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', 
      137: '0xdc9232e2df177d7a12fdff6ecbab114e2231198d' // WMATIC - WETH
    },
    tokenSymbol: 'WETH',
    tokenAddresses: {
      97: '',
      56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
      137: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619'
    },
    quoteTokenSymbol: QuoteToken.ETH,
    quoteTokenAdresses:  {
      97: '',
      56: '', 
      137: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619',
    },
    stratType: 'quickswap',
    strategyAddress: {
      97: '',
      56: '', // Strategy contract
      137: '0xf876Bbb3302AB9BF3666aaAA26eF6C4BC358170f', // Strategy contract
    },
    qsStakingAddress: {
      97: '',
      56: '',
      137: '0x070D182EB7E9C3972664C959CE58C5fC6219A7ad'
    },
  },
  // { //FUCKED POOL
  //   pid: 15,
  //   risk: 5,
  //   isTokenOnly: false,
  //   lpSymbol: 'USDC - WETH',
  //   lpAddresses: {
  //     97: '',
  //     56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', 
  //     137: '0x853ee4b2a13f8a742d64c8f088be7ba2131f670d' // WMATIC - WETH
  //   },
  //   tokenSymbol: 'WETH',
  //   tokenAddresses: {
  //     97: '',
  //     56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
  //     137: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619'
  //   },
  //   quoteTokenSymbol: QuoteToken.ETH,
  //   quoteTokenAdresses:  {
  //     97: '',
  //     56: '', 
  //     137: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619',
  //   },
  //   stratType: 'quickswap',
  //   strategyAddress: {
  //     97: '',
  //     56: '', // Strategy contract
  //     137: '0x1E566d078241BD91e2504b7592fCA4AFD0A560D2', // Strategy contract
  //   },
  //   qsStakingAddress: {
  //     97: '',
  //     56: '',
  //     137: '0x4A73218eF2e820987c59F838906A82455F42D98b'
  //   },
  // },
  {
    pid: 16,
    risk: 5,
    isTokenOnly: false,
    isKRILLPool: true,
    lpSymbol: 'USDC - WETH',
    lpAddresses: {
      97: '',
      56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', 
      137: '0x853ee4b2a13f8a742d64c8f088be7ba2131f670d' // WMATIC - WETH
    },
    tokenSymbol: 'WETH',
    tokenAddresses: {
      97: '',
      56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
      137: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619'
    },
    quoteTokenSymbol: QuoteToken.ETH,
    quoteTokenAdresses:  {
      97: '',
      56: '', 
      137: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619',
    },
    stratType: 'quickswap',
    strategyAddress: {
      97: '',
      56: '', // Strategy contract
      137: '0xDEE3562fbbB5FaDF384DCE23a02a3B0e22857C8a', // Strategy contract
    },
    qsStakingAddress: {
      97: '',
      56: '',
      137: '0x4A73218eF2e820987c59F838906A82455F42D98b'
    },
  },
  {
    pid: 17,
    risk: 5,
    isTokenOnly: false,
    isKRILLPool: true,
    lpSymbol: 'USDC - USDT',
    lpAddresses: {
      97: '',
      56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', 
      137: '0x2cf7252e74036d1da831d11089d326296e64a728' // WMATIC - WETH
    },
    tokenSymbol: 'USDT',
    tokenAddresses: {
      97: '',
      56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
      137: '0xc2132d05d31c914a87c6611c10748aeb04b58e8f'
    },
    quoteTokenSymbol: QuoteToken.BUSD,
    quoteTokenAdresses: contracts.busd,
    stratType: 'quickswap',
    strategyAddress: {
      97: '',
      56: '', // Strategy contract
      137: '0x645420f8F9B4b02D24164070F34475673ddC60ae', // Strategy contract
    },
    qsStakingAddress: {
      97: '',
      56: '',
      137: '0x251d9837a13F38F3Fe629ce2304fa00710176222'
    },
  },
  // {
  //   pid: 18,
  //   risk: 5,
  //   isTokenOnly: false,
  //   isKRILLPool: true,
  //   lpSymbol: 'KRILL - USDC',
  //   lpAddresses: {
  //     97: '',
  //     56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', // WMATIC - WETH
  //     137: '0x6405Ebc22cB0899FC21f414085Ac4044B4721a0d' // KRILL - USDC
  //   },
  //   tokenSymbol: 'USDC',
  //   tokenAddresses: {
  //     97: '',
  //     56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
  //     137: '0x2791bca1f2de4661ed88a30c99a7a9449aa84174'
  //   },
  //   quoteTokenSymbol: QuoteToken.BUSD,
  //   quoteTokenAdresses: contracts.busd,
  //   stratType: 'quickswap',
  //   strategyAddress: {
  //     97: '',
  //     56: '0xA345b3453c6adD921347002a4805f9D4B92f4309', // Strategy contract
  //     137: '0x93E3d901c93A7106be25DB8bB6054e9CdD1b8E02', // Strategy contract
  //   },
  //   qsStakingAddress: {
  //     97: '',
  //     56: '',
  //     137: '0x589a0C538c056b99B0D9F40f8e79DeABede87060'
  //   },
  // },
  // {
  //   pid: 19,
  //   risk: 5,
  //   isTokenOnly: false,
  //   isKRILLPool: true,
  //   lpSymbol: 'KRILL - USDC',
  //   lpAddresses: {
  //     97: '',
  //     56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', // WMATIC - WETH
  //     137: '0x6405Ebc22cB0899FC21f414085Ac4044B4721a0d' // KRILL - USDC
  //   },
  //   tokenSymbol: 'USDC',
  //   tokenAddresses: {
  //     97: '',
  //     56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
  //     137: '0x2791bca1f2de4661ed88a30c99a7a9449aa84174'
  //   },
  //   quoteTokenSymbol: QuoteToken.BUSD,
  //   quoteTokenAdresses: contracts.busd,
  //   stratType: 'quickswap',
  //   strategyAddress: {
  //     97: '',
  //     56: '0xA345b3453c6adD921347002a4805f9D4B92f4309', // Strategy contract
  //     137: '0xf377c609c7bcd620e854C06bd19f1f77cd2de573', // Strategy contract
  //   },
  //   qsStakingAddress: {
  //     97: '',
  //     56: '',
  //     137: '0x589a0C538c056b99B0D9F40f8e79DeABede87060'
  //   },
  // },
  // {
  //   pid: 20,
  //   risk: 5,
  //   isTokenOnly: false,
  //   isKRILLPool: true,
  //   lpSymbol: 'KRILL - USDC',
  //   lpAddresses: {
  //     97: '',
  //     56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', // WMATIC - WETH
  //     137: '0x6405Ebc22cB0899FC21f414085Ac4044B4721a0d' // KRILL - USDC
  //   },
  //   tokenSymbol: 'USDC',
  //   tokenAddresses: {
  //     97: '',
  //     56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
  //     137: '0x2791bca1f2de4661ed88a30c99a7a9449aa84174'
  //   },
  //   quoteTokenSymbol: QuoteToken.BUSD,
  //   quoteTokenAdresses: contracts.busd,
  //   stratType: 'quickswap',
  //   strategyAddress: {
  //     97: '',
  //     56: '0xA345b3453c6adD921347002a4805f9D4B92f4309', // Strategy contract
  //     137: '0x578D3334F7d6A3Dd19B1d6eacABCF6E2D18898eF', // Strategy contract
  //   },
  //   qsStakingAddress: {
  //     97: '',
  //     56: '',
  //     137: '0x589a0C538c056b99B0D9F40f8e79DeABede87060'
  //   },
  // },
  // {
  //   pid: 21,
  //   risk: 5,
  //   isTokenOnly: false,
  //   isKRILLPool: true,
  //   lpSymbol: 'KRILL - USDC',
  //   lpAddresses: {
  //     97: '',
  //     56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', // WMATIC - WETH
  //     137: '0x6405Ebc22cB0899FC21f414085Ac4044B4721a0d' // KRILL - USDC
  //   },
  //   tokenSymbol: 'USDC',
  //   tokenAddresses: {
  //     97: '',
  //     56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
  //     137: '0x2791bca1f2de4661ed88a30c99a7a9449aa84174'
  //   },
  //   quoteTokenSymbol: QuoteToken.BUSD,
  //   quoteTokenAdresses: contracts.busd,
  //   stratType: 'quickswap',
  //   strategyAddress: {
  //     97: '',
  //     56: '0xA345b3453c6adD921347002a4805f9D4B92f4309', // Strategy contract
  //     137: '0x9Fa05d987d8344701DeA21F0dC279981E632A298', // Strategy contract
  //   },
  //   qsStakingAddress: {
  //     97: '',
  //     56: '',
  //     137: '0x589a0C538c056b99B0D9F40f8e79DeABede87060'
  //   },
  // },
  // {
  //   pid: 22,
  //   risk: 5,
  //   isTokenOnly: false,
  //   isKRILLPool: true,
  //   lpSymbol: 'KRILL - QUICK',
  //   lpAddresses: {
  //     97: '',
  //     56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', // WMATIC - WETH
  //     137: '0xfC24a83a657a1F3f299A5f801AF8816e2d14fF46' // KRILL - QUICK
  //   },
  //   tokenSymbol: 'QUICK',
  //   tokenAddresses: {
  //     97: '',
  //     56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
  //     137: '0x831753DD7087CaC61aB5644b308642cc1c33Dc13'
  //   },
  //   quoteTokenSymbol: QuoteToken.CAKE,
  //   quoteTokenAdresses: contracts.cake,
  //   stratType: 'quickswap',
  //   strategyAddress: {
  //     97: '',
  //     56: '0xA345b3453c6adD921347002a4805f9D4B92f4309', // Strategy contract
  //     137: '0x7522AF284CCf71597266E77E2BA8d514bEF6b9dA', // Strategy contract
  //   },
  //   qsStakingAddress: {
  //     97: '',
  //     56: '',
  //     137: '0xD3435396c763aBA84FD6C6FBFA94243Fc033227c'
  //   },
  // },
  {
    pid: 24,
    risk: 5,
    isTokenOnly: false,
    isKRILLPool: true,
    lpSymbol: 'KRILL - USDC',
    lpAddresses: {
      97: '',
      56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', // WMATIC - WETH
      137: '0x6405Ebc22cB0899FC21f414085Ac4044B4721a0d' // KRILL - USDC
    },
    tokenSymbol: 'USDC',
    tokenAddresses: {
      97: '',
      56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
      137: '0x2791bca1f2de4661ed88a30c99a7a9449aa84174'
    },
    quoteTokenSymbol: QuoteToken.BUSD,
    quoteTokenAdresses: contracts.busd,
    stratType: 'quickswap',
    strategyAddress: {
      97: '',
      56: '0xA345b3453c6adD921347002a4805f9D4B92f4309', // Strategy contract
      137: '0x6Fe13c8c29Dacc4EFE5aD995A1d2B8bF91eD0410', // Strategy contract
    },
    qsStakingAddress: {
      97: '',
      56: '',
      137: '0x589a0C538c056b99B0D9F40f8e79DeABede87060'
    },
  },
  {
    pid: 23,
    risk: 5,
    isTokenOnly: false,
    isKRILLPool: true,
    lpSymbol: 'KRILL - QUICK',
    lpAddresses: {
      97: '',
      56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', // WMATIC - WETH
      137: '0xfC24a83a657a1F3f299A5f801AF8816e2d14fF46' // KRILL - QUICK
    },
    tokenSymbol: 'QUICK',
    tokenAddresses: {
      97: '',
      56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
      137: '0x831753DD7087CaC61aB5644b308642cc1c33Dc13'
    },
    quoteTokenSymbol: QuoteToken.CAKE,
    quoteTokenAdresses: contracts.cake,
    stratType: 'quickswap',
    strategyAddress: {
      97: '',
      56: '0xA345b3453c6adD921347002a4805f9D4B92f4309', // Strategy contract
      137: '0x3a15892fA9e50e53feFB45B15BE23E3969373538', // Strategy contract
    },
    qsStakingAddress: {
      97: '',
      56: '',
      137: '0xD3435396c763aBA84FD6C6FBFA94243Fc033227c'
    },
  },
  // {
  //   pid: 25,
  //   risk: 5,
  //   isTokenOnly: false,
  //   isKRILLPool: true,
  //   lpSymbol: 'KRILL - USDC',
  //   lpAddresses: {
  //     97: '',
  //     56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', // WMATIC - WETH
  //     137: '0x6405Ebc22cB0899FC21f414085Ac4044B4721a0d' // KRILL - USDC
  //   },
  //   tokenSymbol: 'USDC',
  //   tokenAddresses: {
  //     97: '',
  //     56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
  //     137: '0x2791bca1f2de4661ed88a30c99a7a9449aa84174'
  //   },
  //   quoteTokenSymbol: QuoteToken.BUSD,
  //   quoteTokenAdresses: contracts.busd,
  //   stratType: 'quickswap',
  //   strategyAddress: {
  //     97: '',
  //     56: '0xA345b3453c6adD921347002a4805f9D4B92f4309', // Strategy contract
  //     137: '0x6Fe13c8c29Dacc4EFE5aD995A1d2B8bF91eD0410', // Strategy contract
  //   },
  //   qsStakingAddress: {
  //     97: '',
  //     56: '',
  //     137: '0x589a0C538c056b99B0D9F40f8e79DeABede87060'
  //   },
  // },
  // {
  //   pid: 25,
  //   risk: 5,
  //   isTokenOnly: false,
  //   isKRILLPool: true,
  //   lpSymbol: 'KRILL - USDC',
  //   lpAddresses: {
  //     97: '',
  //     56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', // WMATIC - WETH
  //     137: '0x6405Ebc22cB0899FC21f414085Ac4044B4721a0d' // KRILL - USDC
  //   },
  //   tokenSymbol: 'USDC',
  //   tokenAddresses: {
  //     97: '',
  //     56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
  //     137: '0x2791bca1f2de4661ed88a30c99a7a9449aa84174'
  //   },
  //   quoteTokenSymbol: QuoteToken.BUSD,
  //   quoteTokenAdresses: contracts.busd,
  //   stratType: 'quickswap',
  //   strategyAddress: {
  //     97: '',
  //     56: '0xA345b3453c6adD921347002a4805f9D4B92f4309', // Strategy contract
  //     137: '0x0784ed2022cc93B30Fc2857623d6567d43F15E72', // Strategy contract
  //   },
  //   qsStakingAddress: {
  //     97: '',
  //     56: '',
  //     137: '0x589a0C538c056b99B0D9F40f8e79DeABede87060'
  //   },
  // },
  // {
  //   pid: 26,
  //   risk: 5,
  //   isTokenOnly: false,
  //   isKRILLPool: true,
  //   lpSymbol: 'KRILL - USDC',
  //   lpAddresses: {
  //     97: '',
  //     56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', // WMATIC - WETH
  //     137: '0x6405Ebc22cB0899FC21f414085Ac4044B4721a0d' // KRILL - USDC
  //   },
  //   tokenSymbol: 'USDC',
  //   tokenAddresses: {
  //     97: '',
  //     56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
  //     137: '0x2791bca1f2de4661ed88a30c99a7a9449aa84174'
  //   },
  //   quoteTokenSymbol: QuoteToken.BUSD,
  //   quoteTokenAdresses: contracts.busd,
  //   stratType: 'quickswap',
  //   strategyAddress: {
  //     97: '',
  //     56: '0xA345b3453c6adD921347002a4805f9D4B92f4309', // Strategy contract
  //     137: '0xf42ddd5154A15Ba2255412744785E5887EE625EF', // Strategy contract
  //   },
  //   qsStakingAddress: {
  //     97: '',
  //     56: '',
  //     137: '0x589a0C538c056b99B0D9F40f8e79DeABede87060'
  //   },
  // },
  // {
  //   pid: 27,
  //   risk: 5,
  //   isTokenOnly: false,
  //   isKRILLPool: true,
  //   lpSymbol: 'KRILL - USDC',
  //   lpAddresses: {
  //     97: '',
  //     56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', // WMATIC - WETH
  //     137: '0x6405Ebc22cB0899FC21f414085Ac4044B4721a0d' // KRILL - USDC
  //   },
  //   tokenSymbol: 'USDC',
  //   tokenAddresses: {
  //     97: '',
  //     56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
  //     137: '0x2791bca1f2de4661ed88a30c99a7a9449aa84174'
  //   },
  //   quoteTokenSymbol: QuoteToken.BUSD,
  //   quoteTokenAdresses: contracts.busd,
  //   stratType: 'quickswap',
  //   strategyAddress: {
  //     97: '',
  //     56: '0xA345b3453c6adD921347002a4805f9D4B92f4309', // Strategy contract
  //     137: '0xf42ddd5154A15Ba2255412744785E5887EE625EF', // Strategy contract
  //   },
  //   qsStakingAddress: {
  //     97: '',
  //     56: '',
  //     137: '0x589a0C538c056b99B0D9F40f8e79DeABede87060'
  //   },
  // },
  {
    pid: 31,
    risk: 5,
    isTokenOnly: false,
    isKRILLPool: true,
    lpSymbol: 'KRILL - USDC',
    lpAddresses: {
      97: '',
      56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', // WMATIC - WETH
      137: '0x6405Ebc22cB0899FC21f414085Ac4044B4721a0d' // KRILL - USDC
    },
    tokenSymbol: 'USDC',
    tokenAddresses: {
      97: '',
      56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
      137: '0x2791bca1f2de4661ed88a30c99a7a9449aa84174'
    },
    quoteTokenSymbol: QuoteToken.BUSD,
    quoteTokenAdresses: contracts.busd,
    stratType: 'quickswap',
    strategyAddress: {
      97: '',
      56: '0xA345b3453c6adD921347002a4805f9D4B92f4309', // Strategy contract
      137: '0x57F380546CF7d60Cb73a7185cc7D5111ce746353', // Strategy contract
    },
    qsStakingAddress: {
      97: '',
      56: '',
      137: '0x589a0C538c056b99B0D9F40f8e79DeABede87060'
    },
  },
  {
    pid: 32,
    risk: 5,
    isTokenOnly: false,
    isKRILLPool: true,
    lpSymbol: 'KRILL - QUICK',
    lpAddresses: {
      97: '',
      56: '0xc4e595acdd7d12fec385e5da5d43160e8a0bac0e', // WMATIC - WETH
      137: '0xfC24a83a657a1F3f299A5f801AF8816e2d14fF46' // KRILL - QUICK
    },
    tokenSymbol: 'QUICK',
    tokenAddresses: {
      97: '',
      56: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', 
      137: '0x831753DD7087CaC61aB5644b308642cc1c33Dc13'
    },
    quoteTokenSymbol: QuoteToken.CAKE,
    quoteTokenAdresses: contracts.cake,
    stratType: 'quickswap',
    strategyAddress: {
      97: '',
      56: '0xA345b3453c6adD921347002a4805f9D4B92f4309', // Strategy contract
      137: '0x871c619426d80757743091635100dA5fBf9E437d', // Strategy contract
    },
    qsStakingAddress: {
      97: '',
      56: '',
      137: '0xD3435396c763aBA84FD6C6FBFA94243Fc033227c'
    },
  },
]


export default autoFarms
