import { PoolConfig, QuoteToken, PoolCategory } from './types'

const pools: PoolConfig[] = [
  {
    sousId: 20,
    tokenName: 'WMATIC',
    stakingTokenName: QuoteToken.KRILL,
    stakingTokenAddress: {
      137: '0x05089C9EBFFa4F0AcA269e32056b1b36B37ED71b',
      97: '',
      56: '', // KRILL
    },
    contractAddress: {
      137: '0x5ED37920412415B1d2F0F25e44776F0BE709B4e3',
      97: '',
      56: '', // SmartChef
    },
    rewardTokenAddress: {
      137: '0x0d500b1d8e8ef31e21c99d1db9a6444d3adf1270',
      97: '',
      56: '', // WMATIC
    },
    poolCategory: PoolCategory.COMMUNITY,
    projectLink: 'https://polygon.technology/',
    harvest: true,
    tokenPerBlock: '0.0165343915343915',
    sortOrder: 1,
    isFinished: false,
    tokenDecimals: 18,
    burnFee: 100,
    weeklyroi: '~ 60%'
  }, 
  {
    sousId: 21,
    tokenName: 'ELK',
    stakingTokenName: QuoteToken.KRILL,
    stakingTokenAddress: {
      137: '0x05089C9EBFFa4F0AcA269e32056b1b36B37ED71b',
      97: '',
      56: '', // KRILL
    },
    contractAddress: {
      137: '0x85Ac6e29ee5Ab7665701CfdCC443dF50d5E67e74',
      97: '',
      56: '', // SmartChef
    },
    rewardTokenAddress: {
      137: '0xE1C8f3d529BEa8E3fA1FAC5B416335a2f998EE1C', // ELK
      97: '',
      56: '', // WMATIC
    },
    poolCategory: PoolCategory.COMMUNITY,
    projectLink: 'https://elk.finance/',
    harvest: true,
    tokenPerBlock: '0.002662037037037',
    sortOrder: 2,
    isFinished: false,
    tokenDecimals: 18,
    burnFee: 100,
    weeklyroi: 'Starting Saturday 13:30 UTC'
  },
]

export default pools
